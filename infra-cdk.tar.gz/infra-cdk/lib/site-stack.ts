import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as cloudfront from "aws-cdk-lib/aws-cloudfront";
import * as origins from "aws-cdk-lib/aws-cloudfront-origins";
import * as iam from "aws-cdk-lib/aws-iam";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as amplify from "@aws-cdk/aws-amplify-alpha";
import * as acm from "aws-cdk-lib/aws-certificatemanager";
import * as route53 from "aws-cdk-lib/aws-route53";
import * as route53targets from "aws-cdk-lib/aws-route53-targets";
import * as ssm from "aws-cdk-lib/aws-ssm";
import * as path from "path";

export interface SiteStackProps extends cdk.StackProps {
  /**
   * Your domain name, e.g. "example.com"
   * A CloudFront distribution will be created at cdn.{domainName}
   * The Amplify app will be at {domainName} / www.{domainName}
   */
  domainName: string;

  /**
   * Friendly name prefix for all resources, e.g. "mysite"
   * Used in resource names to avoid collisions.
   */
  appName: string;

  /**
   * Path to your compiled Rust lambda bootstrap binary directory.
   * The directory must contain a file named `bootstrap` (the Rust binary).
   * Build it first:  cargo build --release --target x86_64-unknown-linux-musl
   *                  cp target/x86_64-unknown-linux-musl/release/<fn> lambda-bin/bootstrap
   */
  lambdaBinDir: string;

  /**
   * Your GitHub repo for Amplify, e.g. "owner/repo"
   */
  githubRepo: string;

  /**
   * Branch to deploy from Amplify
   */
  githubBranch?: string;

  /**
   * GitHub personal access token stored in SSM Parameter Store (SecureString).
   * Create it with:
   *   aws ssm put-parameter --name /mysite/github-token --value ghp_xxx \
   *     --type SecureString
   */
  githubTokenSsmPath: string;

  /**
   * Extra environment variables written into .env.production during Amplify build.
   * Keys become the variable names; values are the literal strings.
   */
  frontendEnvVars?: Record<string, string>;
}

export class SiteStack extends cdk.Stack {
  public readonly bucket: s3.Bucket;
  public readonly distribution: cloudfront.Distribution;
  public readonly lambdaFn: lambda.Function;
  public readonly api: apigateway.RestApi;
  public readonly userPool: cognito.UserPool;

  constructor(scope: Construct, id: string, props: SiteStackProps) {
    super(scope, id, props);

    const { appName, domainName } = props;
    const branch = props.githubBranch ?? "main";

    // ──────────────────────────────────────────────────────────────
    // 1. COGNITO — User Pool + admin group
    // ──────────────────────────────────────────────────────────────
    this.userPool = new cognito.UserPool(this, "UserPool", {
      userPoolName: `${appName}-user-pool`,
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      standardAttributes: {
        email: { required: true, mutable: true },
      },
      customAttributes: {
        newsletterOptIn: new cognito.BooleanAttribute({ mutable: true }),
      },
      passwordPolicy: {
        minLength: 8,
        requireLowercase: true,
        requireUppercase: true,
        requireDigits: true,
        requireSymbols: false,
      },
      accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
      removalPolicy: cdk.RemovalPolicy.RETAIN, // never accidentally delete users
    });

    new cognito.CfnUserPoolGroup(this, "AdminGroup", {
      userPoolId: this.userPool.userPoolId,
      groupName: "admin",
      description: "Site administrators",
    });

    const userPoolClient = new cognito.UserPoolClient(this, "UserPoolClient", {
      userPool: this.userPool,
      authFlows: {
        userPassword: true,
        userSrp: true,
      },
      generateSecret: false,
    });

    // ──────────────────────────────────────────────────────────────
    // 2. S3 BUCKET
    // ──────────────────────────────────────────────────────────────
    this.bucket = new s3.Bucket(this, "ContentBucket", {
      bucketName: `${appName}-frontend-bucket`,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL, // CloudFront OAC handles public access
      encryption: s3.BucketEncryption.S3_MANAGED,
      versioned: false,
      removalPolicy: cdk.RemovalPolicy.RETAIN,
      cors: [
        {
          allowedMethods: [s3.HttpMethods.GET],
          allowedOrigins: [`https://${domainName}`, `https://www.${domainName}`],
          allowedHeaders: ["*"],
        },
      ],
    });

    // ──────────────────────────────────────────────────────────────
    // 3. CLOUDFRONT — OAC + distribution
    //    Public paths: /thumbs/*, /images/*, /downloads/*
    //    Private path: /content/* (Amplify build role only)
    // ──────────────────────────────────────────────────────────────

    // Look up hosted zone for the domain (must already exist in Route 53)
    const hostedZone = route53.HostedZone.fromLookup(this, "Zone", {
      domainName,
    });

    // ACM cert must be in us-east-1 for CloudFront
    const cdnCert = new acm.DnsValidatedCertificate(this, "CdnCert", {
      domainName: `cdn.${domainName}`,
      hostedZone,
      region: "us-east-1", // CloudFront requirement
    });

    const oac = new cloudfront.S3OriginAccessControl(this, "OAC", {
      description: `OAC for ${appName} bucket`,
    });

    this.distribution = new cloudfront.Distribution(this, "Distribution", {
      comment: `${appName} CDN`,
      domainNames: [`cdn.${domainName}`],
      certificate: cdnCert,
      defaultBehavior: {
        // Default: only serve public media folders
        origin: origins.S3BucketOrigin.withOriginAccessControl(this.bucket, {
          originAccessControl: oac,
        }),
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        allowedMethods: cloudfront.AllowedMethods.ALLOW_GET_HEAD,
        cachedMethods: cloudfront.CachedMethods.CACHE_GET_HEAD,
      },
      additionalBehaviors: {
        // Explicitly allow these three public paths
        "/thumbs/*": {
          origin: origins.S3BucketOrigin.withOriginAccessControl(this.bucket, {
            originAccessControl: oac,
          }),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
          cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        },
        "/images/*": {
          origin: origins.S3BucketOrigin.withOriginAccessControl(this.bucket, {
            originAccessControl: oac,
          }),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
          cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        },
        "/downloads/*": {
          origin: origins.S3BucketOrigin.withOriginAccessControl(this.bucket, {
            originAccessControl: oac,
          }),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
          cachePolicy: cloudfront.CachePolicy.CACHING_LONGER_CACHING,
        },
      },
      // Block /content/* at the CDN edge — it's build-only, never public
      // (achieved via bucket policy; no CF behavior needed)
    });

    // Bucket policy — CloudFront OAC, Amplify build role, Lambda role
    // We build this explicitly so all principals + conditions are in one place.
    const amplifyBuildRoleArn = new cdk.CfnParameter(this, "AmplifyBuildRoleArn", {
      type: "String",
      description:
        "ARN of the Amplify Console backend role (e.g. arn:aws:iam::ACCOUNT:role/APPNAME-amplifyconsole-backend-role). " +
        "Find it in IAM → Roles after creating the Amplify app, or pass it via context.",
      default: "",
    }).valueAsString;

    // Grant CloudFront OAC read on the whole bucket (thumbs, images, downloads)
    this.bucket.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: "AllowCloudFrontServicePrincipal",
        effect: iam.Effect.ALLOW,
        principals: [new iam.ServicePrincipal("cloudfront.amazonaws.com")],
        actions: ["s3:GetObject"],
        resources: [this.bucket.arnForObjects("*")],
        conditions: {
          ArnLike: {
            "AWS:SourceArn": `arn:aws:cloudfront::${this.account}:distribution/${this.distribution.distributionId}`,
          },
        },
      })
    );

    // Grant Amplify build role: list + get on content/ only
    this.bucket.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: "AllowAmplifyBuildListContent",
        effect: iam.Effect.ALLOW,
        principals: [new iam.ArnPrincipal(amplifyBuildRoleArn)],
        actions: ["s3:ListBucket"],
        resources: [this.bucket.bucketArn],
        conditions: { StringLike: { "s3:prefix": "content/*" } },
      })
    );
    this.bucket.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: "AllowAmplifyBuildGetContent",
        effect: iam.Effect.ALLOW,
        principals: [new iam.ArnPrincipal(amplifyBuildRoleArn)],
        actions: ["s3:GetObject"],
        resources: [this.bucket.arnForObjects("content/*")],
      })
    );

    // ──────────────────────────────────────────────────────────────
    // 4. LAMBDA ROLE — scoped to content/ and media/ read/write
    // ──────────────────────────────────────────────────────────────
    const lambdaRole = new iam.Role(this, "LambdaS3Role", {
      roleName: `${appName}-lambda-s3-role`,
      assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName(
          "service-role/AWSLambdaBasicExecutionRole"
        ),
      ],
    });

    // List on bucket scoped to content/ and media/
    lambdaRole.addToPolicy(
      new iam.PolicyStatement({
        sid: "LambdaListBucket",
        actions: ["s3:ListBucket"],
        resources: [this.bucket.bucketArn],
        conditions: {
          StringLike: {
            "s3:prefix": ["content/*", "media/*"],
          },
        },
      })
    );

    // Full object access on content/ and media/
    lambdaRole.addToPolicy(
      new iam.PolicyStatement({
        sid: "LambdaRWObjects",
        actions: ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
        resources: [
          this.bucket.arnForObjects("content/*"),
          this.bucket.arnForObjects("media/*"),
        ],
      })
    );

    // Add lambda role to bucket policy too
    this.bucket.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: "AllowLambdaListContentAndMedia",
        effect: iam.Effect.ALLOW,
        principals: [new iam.ArnPrincipal(lambdaRole.roleArn)],
        actions: ["s3:ListBucket"],
        resources: [this.bucket.bucketArn],
        conditions: {
          StringLike: { "s3:prefix": ["content/*", "media/*"] },
        },
      })
    );
    this.bucket.addToResourcePolicy(
      new iam.PolicyStatement({
        sid: "AllowLambdaRWContentAndMedia",
        effect: iam.Effect.ALLOW,
        principals: [new iam.ArnPrincipal(lambdaRole.roleArn)],
        actions: ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
        resources: [
          this.bucket.arnForObjects("content/*"),
          this.bucket.arnForObjects("media/*"),
        ],
      })
    );

    // ──────────────────────────────────────────────────────────────
    // 5. RUST LAMBDA
    //    Expects a pre-built `bootstrap` binary in props.lambdaBinDir
    //    Build: cargo build --release --target x86_64-unknown-linux-musl
    //           cp target/.../release/<name> lambda-bin/bootstrap
    // ──────────────────────────────────────────────────────────────
    this.lambdaFn = new lambda.Function(this, "RustLambda", {
      functionName: `${appName}-api`,
      runtime: lambda.Runtime.PROVIDED_AL2023,
      architecture: lambda.Architecture.X86_64,
      handler: "bootstrap", // Rust custom runtime ignores this but it's required
      code: lambda.Code.fromAsset(props.lambdaBinDir),
      role: lambdaRole,
      timeout: cdk.Duration.seconds(30),
      memorySize: 256,
      environment: {
        // Automatically wired — no hardcoding needed
        S3_BUCKET_NAME: this.bucket.bucketName,
        S3_BUCKET_REGION: this.region,
        COGNITO_USER_POOL_ID: this.userPool.userPoolId,
        COGNITO_CLIENT_ID: userPoolClient.userPoolClientId,
        CDN_BASE_URL: `https://cdn.${domainName}`,
        RUST_LOG: "info",
      },
    });

    // ──────────────────────────────────────────────────────────────
    // 6. API GATEWAY + COGNITO AUTHORIZER
    //    Lambda checks cognito:groups for "admin" before proceeding
    // ──────────────────────────────────────────────────────────────
    this.api = new apigateway.RestApi(this, "Api", {
      restApiName: `${appName}-api`,
      description: `${appName} backend API`,
      defaultCorsPreflightOptions: {
        allowOrigins: [
          `https://${domainName}`,
          `https://www.${domainName}`,
          // Allow localhost for dev
          "http://localhost:3000",
          "http://localhost:3001",
        ],
        allowMethods: apigateway.Cors.ALL_METHODS,
        allowHeaders: [
          "Content-Type",
          "Authorization",
          "X-Amz-Date",
          "X-Api-Key",
        ],
      },
      deployOptions: {
        stageName: "v1",
        throttlingRateLimit: 100,
        throttlingBurstLimit: 200,
      },
    });

    const cognitoAuthorizer = new apigateway.CognitoUserPoolsAuthorizer(
      this,
      "CognitoAuthorizer",
      {
        cognitoUserPools: [this.userPool],
        authorizerName: `${appName}-cognito-auth`,
        identitySource: "method.request.header.Authorization",
        resultsCacheTtl: cdk.Duration.minutes(5),
      }
    );

    const lambdaIntegration = new apigateway.LambdaIntegration(this.lambdaFn, {
      proxy: true, // Lambda receives full API GW event; Rust handler parses it
    });

    // Proxy all routes under /api/{proxy+} to the Rust lambda.
    // The lambda itself checks cognito:groups contains "admin".
    const apiResource = this.api.root.addResource("api");
    const proxyResource = apiResource.addResource("{proxy+}");
    proxyResource.addMethod("ANY", lambdaIntegration, {
      authorizer: cognitoAuthorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });

    // ──────────────────────────────────────────────────────────────
    // 7. AMPLIFY APP
    // ──────────────────────────────────────────────────────────────
    const githubToken = cdk.SecretValue.ssmSecure(props.githubTokenSsmPath);

    const amplifyApp = new amplify.App(this, "AmplifyApp", {
      appName: `${appName}-frontend`,
      sourceCodeProvider: new amplify.GitHubSourceCodeProvider({
        owner: props.githubRepo.split("/")[0],
        repository: props.githubRepo.split("/")[1],
        oauthToken: githubToken,
      }),
      // Build spec is in amplify.yml in the repo root — see that file.
      // We pass all env vars here so they're available during build.
      environmentVariables: {
        NEXT_PUBLIC_API_BASE_URL: this.api.url,
        NEXT_PUBLIC_SITE_URL: `https://${domainName}`,
        NEXT_PUBLIC_CDN_URL: `https://cdn.${domainName}`,
        NEXT_PUBLIC_USER_POOL_ID: this.userPool.userPoolId,
        NEXT_PUBLIC_USER_POOL_CLIENT_ID: userPoolClient.userPoolClientId,
        S3_BUCKET_NAME: this.bucket.bucketName,
        AWS_REGION_NAME: this.region,
        // Any extra vars the caller passed in
        ...props.frontendEnvVars,
        // Required by Amplify for Next.js SSR
        _LIVE_UPDATES: JSON.stringify([
          { name: "Next.js version", pkg: "next-version", type: "internal", version: "latest" },
        ]),
      },
    });

    const mainBranch = amplifyApp.addBranch(branch, {
      autoBuild: true,
      stage: "PRODUCTION",
    });

    // Custom domain on Amplify
    const amplifyDomain = amplifyApp.addDomain(domainName, {
      enableAutoSubdomain: false,
    });
    amplifyDomain.mapRoot(mainBranch);
    amplifyDomain.mapSubDomain(mainBranch, "www");

    // CDN subdomain → CloudFront
    new route53.ARecord(this, "CdnAliasRecord", {
      zone: hostedZone,
      recordName: "cdn",
      target: route53.RecordTarget.fromAlias(
        new route53targets.CloudFrontTarget(this.distribution)
      ),
    });

    // ──────────────────────────────────────────────────────────────
    // 8. OUTPUTS — printed after `cdk deploy`, also visible in
    //    CloudFormation → Outputs tab
    // ──────────────────────────────────────────────────────────────
    new cdk.CfnOutput(this, "BucketName", {
      value: this.bucket.bucketName,
      description: "S3 content bucket name",
      exportName: `${appName}-bucket-name`,
    });

    new cdk.CfnOutput(this, "BucketRegion", {
      value: this.region,
      exportName: `${appName}-bucket-region`,
    });

    new cdk.CfnOutput(this, "DistributionId", {
      value: this.distribution.distributionId,
      exportName: `${appName}-cf-distribution-id`,
    });

    new cdk.CfnOutput(this, "CdnUrl", {
      value: `https://cdn.${domainName}`,
      exportName: `${appName}-cdn-url`,
    });

    new cdk.CfnOutput(this, "ApiUrl", {
      value: this.api.url,
      description: "API Gateway invoke URL",
      exportName: `${appName}-api-url`,
    });

    new cdk.CfnOutput(this, "UserPoolId", {
      value: this.userPool.userPoolId,
      exportName: `${appName}-user-pool-id`,
    });

    new cdk.CfnOutput(this, "UserPoolClientId", {
      value: userPoolClient.userPoolClientId,
      exportName: `${appName}-user-pool-client-id`,
    });

    new cdk.CfnOutput(this, "AmplifyAppId", {
      value: amplifyApp.appId,
      exportName: `${appName}-amplify-app-id`,
    });

    new cdk.CfnOutput(this, "LambdaRoleArn", {
      value: lambdaRole.roleArn,
      description:
        "Add this to the Amplify Console backend role ARN parameter if not already set",
      exportName: `${appName}-lambda-role-arn`,
    });
  }
}
