# Site Infrastructure — AWS CDK

One `cdk deploy` creates and wires together:

| Resource | What it does |
|----------|-------------|
| **S3 bucket** | Stores content/, thumbs/, images/, downloads/ |
| **CloudFront distribution** | CDN at `cdn.yourdomain.com` — serves thumbs/, images/, downloads/ publicly |
| **IAM roles** | Lambda role (scoped to content/ + media/), Amplify build role access |
| **Cognito User Pool** | Email auth, `admin` group, custom `newsletterOptIn` attribute |
| **Rust Lambda** | Your pre-built binary, env vars auto-wired (bucket name, region, pool ID) |
| **API Gateway** | `POST/GET /api/{proxy+}` → Lambda, Cognito JWT authorizer |
| **Amplify App** | Connected to GitHub, env vars injected, `aws s3 sync` during preBuild |
| **Route 53 records** | `cdn.` → CloudFront, root + www → Amplify |
| **ACM certificate** | Auto-provisioned for cdn.yourdomain.com (us-east-1 for CloudFront) |

---

## Prerequisites

```bash
# 1. AWS CLI configured
aws configure

# 2. Node + npm
node --version  # >= 18

# 3. CDK CLI
npm install -g aws-cdk

# 4. Bootstrap CDK in your account/region (one-time per account)
cdk bootstrap aws://YOUR_ACCOUNT_ID/us-east-1

# 5. Your domain must already have a hosted zone in Route 53
#    (Route 53 → Hosted zones → Create hosted zone if not)

# 6. Store your GitHub token in SSM
aws ssm put-parameter \
  --name /mysite/github-token \
  --value ghp_YOUR_TOKEN_HERE \
  --type SecureString
```

## Build your Rust Lambda first

```bash
# In your Rust project:
cargo build --release --target x86_64-unknown-linux-musl

# Copy the binary to the lambda-bin/ directory (next to this CDK project)
mkdir -p ../lambda-bin
cp target/x86_64-unknown-linux-musl/release/YOUR_BINARY_NAME ../lambda-bin/bootstrap
```

The binary **must** be named `bootstrap` — that's the AWS custom runtime convention.

## Deploy

```bash
npm install

cdk deploy \
  --context appName=mysite \
  --context domainName=mysite.com \
  --context githubRepo=owner/repo \
  --context githubBranch=main \
  --context githubTokenSsmPath=/mysite/github-token \
  --context lambdaBinDir=../lambda-bin
```

CDK will print all resource ARNs/URLs as outputs when complete.

## After first deploy — one manual step

The Amplify Console creates its own IAM backend role when the app is first built.
You need to pass that role ARN back so the bucket policy allows it:

1. Go to **IAM → Roles**, search for `amplifyconsole-backend-role`
2. Copy the ARN
3. Redeploy with the ARN:

```bash
cdk deploy \
  ... (same context as above) \
  --parameters AmplifyBuildRoleArn=arn:aws:iam::123456789:role/mysite-amplifyconsole-backend-role
```

This is a one-time chicken-and-egg issue: Amplify creates the role on first use,
then you wire the bucket policy to it. After this, deploys are fully automatic.

## Updating infrastructure

```bash
# Preview changes
cdk diff --context appName=mysite --context domainName=mysite.com ...

# Apply changes
cdk deploy --context appName=mysite --context domainName=mysite.com ...
```

## Adding extra frontend env vars

In `bin/infra.ts`, add to the `frontendEnvVars` object:

```typescript
frontendEnvVars: {
  FRONTEND_BUILD_URL: "https://mysite.com",
  DASHBOARD_BUILD_URL: "https://dash.mysite.com",
  URL_PRODUCTS: "https://mysite.com/products",
  // etc.
},
```

---

## About the GUI question

**Short answer: yes, with AWS Service Catalog.**

If you want a point-and-click form in the AWS console that deploys this whole stack,
you can publish it to Service Catalog:

```bash
# 1. Synth to CloudFormation template
cdk synth > site-stack.yaml

# 2. Upload to Service Catalog
aws servicecatalog create-product \
  --name "Site Infrastructure" \
  --product-type CLOUD_FORMATION_TEMPLATE \
  --provisioning-artifact-parameters "Name=v1,Type=CLOUD_FORMATION_TEMPLATE,Info={LoadTemplateFromURL=https://s3.../site-stack.yaml}"
```

Then anyone with access to your AWS account can go to **Service Catalog → Products**,
click "Launch", fill in a form (appName, domainName, githubRepo, etc.), and the
whole stack deploys — no CLI needed.

**For a public product (like Vercel):** that requires AWS Marketplace, a seller
agreement, and significant operational overhead (billing integration, support SLAs,
multi-tenant isolation). Not worth it unless you're building a business around this.
The CDK app is the right tool for your use case.

---

## File structure

```
infra-cdk/
├── bin/
│   └── infra.ts          ← Entry point; configure appName, domainName, etc. here
├── lib/
│   └── site-stack.ts     ← All resources defined here
├── amplify.yml           ← Copy this to your Next.js repo root
├── cdk.json
├── package.json
└── tsconfig.json

../lambda-bin/
└── bootstrap             ← Your compiled Rust binary (must be named bootstrap)
```
